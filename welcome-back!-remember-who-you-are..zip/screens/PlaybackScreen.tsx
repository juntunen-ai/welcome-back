
import React, { useState, useEffect } from 'react';
import { FamilyMember } from '../types';
import { generateMemoryStory } from '../services/geminiService';

interface PlaybackScreenProps {
  member: FamilyMember | null;
  onBack: () => void;
}

const PlaybackScreen: React.FC<PlaybackScreenProps> = ({ member, onBack }) => {
  const [story, setStory] = useState<string>("Thinking...");
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
    if (member) {
      generateMemoryStory("Harri", member.name, member.relationship).then(setStory);
    }
  }, [member]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    // In a real app, this would trigger TTS
    if (!isPlaying && 'speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(story);
      window.speechSynthesis.speak(utterance);
    } else {
      window.speechSynthesis.cancel();
    }
  };

  if (!member) return null;

  return (
    <div className="relative flex min-h-screen w-full flex-col overflow-x-hidden bg-white dark:bg-background-dark font-display text-slate-900 dark:text-white">
      <header className="flex items-center justify-between p-6">
        <button 
          onClick={onBack}
          className="flex h-12 w-12 items-center justify-center rounded-full bg-gray-100 dark:bg-zinc-800 active:scale-90 transition-transform"
        >
          <span className="material-symbols-outlined text-3xl">arrow_back</span>
        </button>
        <div className="h-12 w-12"></div> 
      </header>

      <main className="flex flex-1 flex-col px-6 pb-24">
        <div className="mx-auto w-full max-w-[340px] aspect-[4/5] rounded-[2.5rem] overflow-hidden shadow-2xl ring-4 ring-white dark:ring-zinc-800">
          <img 
            alt={member.name} 
            className="w-full h-full object-cover" 
            src={member.imageUrl} 
          />
        </div>

        <div className="mt-10 flex flex-col items-center text-center space-y-8">
          <div className="space-y-4">
            <h1 className="text-[32px] sm:text-[36px] font-extrabold leading-[1.2] tracking-tight text-balance">
              Listen to {member.name}, <span className="text-primary-blue dark:text-blue-400">your {member.relationship.toLowerCase()}</span>, about who you are, Harri.
            </h1>
            <div className="bg-gray-50 dark:bg-white/5 p-6 rounded-2xl italic text-lg opacity-80 leading-relaxed">
              "{story}"
            </div>
          </div>

          <div className="flex flex-col items-center gap-6">
            <button 
              onClick={togglePlay}
              className={`group relative flex h-32 w-32 items-center justify-center rounded-full bg-primary shadow-[0_10px_40px_rgba(255,214,0,0.4)] active:scale-95 transition-transform duration-150 ${isPlaying ? 'ring-8 ring-primary/20' : ''}`}
            >
              <span className="material-symbols-outlined text-7xl text-black material-fill">
                {isPlaying ? 'pause' : 'play_arrow'}
              </span>
            </button>
            <span className="text-xl font-bold uppercase tracking-widest opacity-60">
              {isPlaying ? 'Now Playing' : 'Tap to listen'}
            </span>
          </div>
        </div>

        <div className="mt-auto flex w-full flex-row items-center justify-center gap-4 py-8">
          <div className="h-3 w-3 rounded-full bg-gray-200 dark:bg-zinc-700"></div>
          <div className="h-3 w-3 rounded-full bg-gray-200 dark:bg-zinc-700"></div>
          <div className="h-3 w-10 rounded-full bg-primary"></div>
        </div>
      </main>
    </div>
  );
};

export default PlaybackScreen;
