
import React from 'react';

interface SettingsScreenProps {
  onBack: () => void;
}

const SettingsScreen: React.FC<SettingsScreenProps> = ({ onBack }) => {
  return (
    <div className="bg-background-dark text-on-surface h-full flex flex-col overflow-hidden pt-10">
      <header className="px-6 py-4 flex items-center gap-4">
        <h1 className="text-3xl font-extrabold tracking-tight">Settings</h1>
      </header>

      <main className="flex-1 overflow-y-auto px-4 pb-12">
        <div className="mt-4 space-y-2">
          <p className="px-4 py-2 text-primary text-xs font-bold uppercase tracking-widest">General</p>
          <SettingItem icon="person" title="Personal Info" subtitle="Manage your name and relations" />
          <SettingItem icon="notifications" title="Notifications" subtitle="Reminders to check in" />
          
          <div className="h-4"></div>
          
          <p className="px-4 py-2 text-primary text-xs font-bold uppercase tracking-widest">Artificial Intelligence</p>
          <div className="px-4 py-4 rounded-3xl bg-surface-variant/40 border border-white/5 space-y-4 mb-2">
            <div>
              <p className="text-sm font-bold mb-3">Core Model</p>
              <select className="w-full bg-surface-variant rounded-xl p-3 border-none text-on-surface font-medium">
                <option>Gemini 3 Pro</option>
                <option>Gemini 3 Flash</option>
              </select>
            </div>
          </div>
          <SettingItem icon="mic_external_on" title="Voice Cloning" subtitle="3 active personalities" hasSwitch checked />
          
          <div className="h-4"></div>
          
          <p className="px-4 py-2 text-primary text-xs font-bold uppercase tracking-widest">System</p>
          <SettingItem icon="dark_mode" title="Display" subtitle="Dark mode" hasSwitch checked />
          <SettingItem icon="info" title="About" subtitle="Version 2.4.0 (Material You)" />
        </div>

        <div className="mt-8 px-4 text-center">
          <p className="text-on-surface/40 text-xs font-medium">Device: Pixel 8 Pro (Mock)</p>
          <p className="text-on-surface/40 text-[10px] mt-1">Memory Companion is powered by Google Gemini</p>
        </div>
      </main>
    </div>
  );
};

const SettingItem: React.FC<{ icon: string; title: string; subtitle: string; hasSwitch?: boolean; checked?: boolean }> = ({ icon, title, subtitle, hasSwitch, checked }) => (
  <div className="flex items-center gap-4 p-4 rounded-3xl active:bg-surface-variant/30 transition-colors">
    <div className="size-12 rounded-2xl bg-surface-variant flex items-center justify-center text-on-surface/80">
      <span className="material-symbols-outlined">{icon}</span>
    </div>
    <div className="flex-1">
      <h4 className="font-bold">{title}</h4>
      <p className="text-xs text-on-surface/50 font-medium">{subtitle}</p>
    </div>
    {hasSwitch ? (
      <div className={`w-12 h-6 rounded-full relative transition-colors ${checked ? 'bg-primary' : 'bg-surface-variant'}`}>
        <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${checked ? 'left-7' : 'left-1'}`}></div>
      </div>
    ) : (
      <span className="material-symbols-outlined text-on-surface/20">chevron_right</span>
    )}
  </div>
);

export default SettingsScreen;
