
import React from 'react';
import { Memory, AppRoute } from '../types';
import { MOCK_MEMORIES } from '../constants';

interface MemoriesScreenProps {
  onSelectMemory: (m: Memory) => void;
  onNavigate: (r: AppRoute) => void;
}

const MemoriesScreen: React.FC<MemoriesScreenProps> = ({ onSelectMemory }) => {
  return (
    <div className="relative flex h-full w-full flex-col bg-background-dark font-display overflow-hidden pt-10">
      <header className="flex flex-shrink-0 items-center justify-between px-6 py-4 sticky top-0 z-10">
        <h1 className="text-3xl font-extrabold tracking-tight text-on-surface">Memories</h1>
        <button className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-variant text-on-surface">
          <span className="material-symbols-outlined">filter_list</span>
        </button>
      </header>

      <main className="flex-1 overflow-y-auto px-4 pb-8">
        <div className="mosaic-grid">
          {MOCK_MEMORIES.map((m, idx) => {
            let tileClass = "tile-small";
            if (idx === 0) tileClass = "tile-large";
            if (idx === 3) tileClass = "tile-wide";

            return (
              <button 
                key={m.id}
                onClick={() => onSelectMemory(m)}
                className={`${tileClass} group relative overflow-hidden rounded-[28px] shadow-sm border border-white/5 active:scale-[0.98] transition-all`}
              >
                <div className="absolute inset-0 bg-cover bg-center" style={{ backgroundImage: `url("${m.imageUrl}")` }}></div>
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-4 right-4 text-left">
                  <p className="text-[10px] font-bold text-primary uppercase tracking-widest">{m.date}</p>
                  <p className="text-sm font-bold text-white line-clamp-1">{m.title}</p>
                </div>
              </button>
            );
          })}
        </div>
        
        <div className="h-8"></div>
        <p className="text-center text-on-surface/30 text-xs font-bold uppercase tracking-widest py-4">End of stream</p>
      </main>
    </div>
  );
};

export default MemoriesScreen;
