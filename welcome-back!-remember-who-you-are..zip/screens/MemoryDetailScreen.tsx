
// This screen is now accessible via specific memory flows if needed, 
// but general music management is moved to the MusicScreen tab.
import React from 'react';
import { Memory } from '../types';

interface MemoryDetailScreenProps {
  memory: Memory;
  onBack: () => void;
}

const MemoryDetailScreen: React.FC<MemoryDetailScreenProps> = ({ memory, onBack }) => {
  return (
    <div className="bg-background-dark text-on-surface min-h-screen font-display overflow-y-auto pb-32 pt-10">
      <div className="flex items-center p-4 pb-2 justify-between sticky top-0 bg-background-dark/90 backdrop-blur-md z-10">
        <button onClick={onBack} className="text-primary flex size-12 shrink-0 items-center justify-center cursor-pointer active:scale-90 transition-transform">
          <span className="material-symbols-outlined text-3xl">arrow_back</span>
        </button>
        <h2 className="text-lg font-bold leading-tight tracking-tight flex-1 text-center">Memory Soundscape</h2>
        <div className="size-12"></div>
      </div>
      
      <main className="flex-1 w-full max-w-md mx-auto px-4 pt-4">
        <h3 className="text-xs uppercase tracking-widest font-bold text-on-surface/40 mb-3 px-2">Selected Memory</h3>
        <div className="flex flex-col items-stretch justify-start rounded-[28px] bg-surface-variant/40 border border-white/5 overflow-hidden shadow-2xl">
          <div className="w-full bg-center bg-no-repeat aspect-video bg-cover" style={{ backgroundImage: `url("${memory.imageUrl}")` }}></div>
          <div className="flex w-full flex-col items-stretch justify-center gap-1 p-5">
            <p className="text-xl font-bold leading-tight tracking-tight">{memory.title}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="material-symbols-outlined text-primary text-sm material-fill">calendar_today</span>
              <p className="text-on-surface/60 text-base font-medium">{memory.date}</p>
            </div>
          </div>
        </div>

        <div className="pt-8">
          <h3 className="text-xs uppercase tracking-widest font-bold text-on-surface/40 mb-4 px-2">Attach Music</h3>
          <div className="grid grid-cols-1 gap-3">
            <button className="flex min-h-[80px] cursor-pointer items-center justify-between gap-3 rounded-[24px] px-6 bg-surface-variant/60 border border-white/5 hover:border-primary transition-all text-lg font-bold w-full shadow-sm active:scale-95">
              <div className="flex items-center gap-4">
                <span className="material-symbols-outlined text-[#1DB954] text-3xl material-fill">podcasts</span>
                <span>Spotify Playlist</span>
              </div>
              <span className="material-symbols-outlined text-primary">add_circle</span>
            </button>
            <button className="flex min-h-[80px] cursor-pointer items-center justify-between gap-3 rounded-[24px] px-6 bg-surface-variant/60 border border-white/5 hover:border-primary transition-all text-lg font-bold w-full shadow-sm active:scale-95">
              <div className="flex items-center gap-4">
                <span className="material-symbols-outlined text-primary text-3xl material-fill">magic_button</span>
                <span>AI Suggested Mix</span>
              </div>
              <span className="material-symbols-outlined text-primary">auto_awesome</span>
            </button>
          </div>
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-6 pb-12 bg-gradient-to-t from-background-dark via-background-dark to-transparent">
        <button 
          onClick={onBack}
          className="w-full max-w-md mx-auto bg-primary text-on-primary h-16 rounded-full font-bold text-xl flex items-center justify-center gap-3 shadow-2xl active:scale-95 transition-transform"
        >
          <span>Save Soundscape</span>
          <span className="material-symbols-outlined material-fill">check_circle</span>
        </button>
      </div>
    </div>
  );
};

export default MemoryDetailScreen;
