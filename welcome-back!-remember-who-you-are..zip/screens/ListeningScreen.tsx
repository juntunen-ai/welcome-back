
import React from 'react';

interface ListeningScreenProps {
  onDone: () => void;
  onClose: () => void;
}

const ListeningScreen: React.FC<ListeningScreenProps> = ({ onDone, onClose }) => {
  return (
    <div className="relative flex h-screen w-full flex-col justify-between overflow-hidden p-6 bg-aura-dark font-space">
      <header className="flex items-center justify-between pt-4">
        <button 
          onClick={onClose}
          className="text-white/40 flex size-12 shrink-0 items-center justify-start active:scale-90 transition-transform"
        >
          <span className="material-symbols-outlined text-3xl">close</span>
        </button>
        <h2 className="text-white text-2xl font-bold leading-tight tracking-[-0.015em] flex-1 text-center pr-12">Listening...</h2>
      </header>

      <div className="flex flex-col items-center justify-center flex-grow relative">
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="aura-glow w-[500px] h-[500px] rounded-full"></div>
        </div>

        <div className="relative w-64 h-64">
          <div className="absolute inset-0 rounded-full border-2 border-primary/20 scale-125"></div>
          <div className="absolute inset-0 rounded-full border border-primary/40 scale-110"></div>
          
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="fluid-shape w-48 h-48 rounded-full animate-pulse"></div>
            <div className="absolute w-32 h-32 bg-primary/60 rounded-full blur-2xl"></div>
          </div>
          
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="material-symbols-outlined text-white text-5xl opacity-80">graphic_eq</span>
          </div>
        </div>

        <div className="mt-16 text-center z-10">
          <p className="text-white/70 text-lg font-medium leading-normal max-w-xs mx-auto">
            I'm listening to your story. Take your time...
          </p>
        </div>
      </div>

      <div className="flex flex-col items-center pb-10 gap-6">
        <div className="flex gap-1 items-center justify-center h-8 mb-4">
          <div className="w-1 bg-primary/40 h-4 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
          <div className="w-1 bg-primary/60 h-6 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
          <div className="w-1 bg-primary h-10 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          <div className="w-1 bg-primary/60 h-6 rounded-full animate-bounce" style={{ animationDelay: '0.3s' }}></div>
          <div className="w-1 bg-primary/40 h-4 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
        </div>

        <div className="w-full max-w-[320px]">
          <button 
            onClick={onDone}
            className="w-full flex cursor-pointer items-center justify-center overflow-hidden rounded-full h-16 bg-primary text-background-dark text-xl font-bold leading-normal tracking-[0.015em] shadow-lg shadow-primary/20 active:scale-95 transition-transform"
          >
            <span className="truncate">Done Speaking</span>
          </button>
        </div>
      </div>

      <div className="fixed top-0 left-0 w-64 h-64 bg-primary/5 blur-[100px] pointer-events-none"></div>
      <div className="fixed bottom-0 right-0 w-80 h-80 bg-purple-600/10 blur-[120px] pointer-events-none"></div>
    </div>
  );
};

export default ListeningScreen;
