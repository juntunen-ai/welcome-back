
import React from 'react';

interface HomeScreenProps {
  onStartListening: () => void;
}

const HomeScreen: React.FC<HomeScreenProps> = ({ onStartListening }) => {
  return (
    <div className="relative flex h-full w-full flex-col items-center justify-center overflow-hidden bg-background-dark px-6 pt-12">
      {/* Hero Section */}
      <div className="flex flex-col items-center justify-center text-center gap-4 mb-12">
        <div className="size-20 rounded-3xl bg-surface-variant flex items-center justify-center mb-2 shadow-inner">
          <span className="material-symbols-outlined text-primary !text-[40px] material-fill">auto_awesome</span>
        </div>
        <div>
          <h1 className="text-on-surface tracking-tight text-3xl font-extrabold leading-tight">
            Hi Harri,
          </h1>
          <p className="text-on-surface/70 text-lg font-medium mt-1">
            Let's rediscover your memories today.
          </p>
        </div>
      </div>

      {/* Main Action Circle */}
      <div className="relative flex items-center justify-center mb-16">
        <div className="absolute w-72 h-72 rounded-full bg-primary/10 pulse-effect"></div>
        <div className="absolute w-60 h-60 rounded-full bg-primary/20 pulse-effect" style={{ animationDelay: '1s' }}></div>
        <button 
          onClick={onStartListening}
          className="relative flex w-48 h-48 cursor-pointer items-center justify-center overflow-hidden rounded-full bg-primary shadow-2xl transition-transform active:scale-90 border-[12px] border-surface"
        >
          <span className="material-symbols-outlined text-on-primary !text-[64px] material-fill">
            mic
          </span>
        </button>
      </div>

      <div className="bg-surface-variant/30 backdrop-blur-md rounded-2xl p-6 w-full max-w-sm border border-white/5">
        <div className="flex items-center gap-4">
          <div className="size-10 rounded-full bg-primary/20 flex items-center justify-center text-primary">
            <span className="material-symbols-outlined !text-xl">lightbulb</span>
          </div>
          <p className="text-on-surface/80 text-sm font-medium leading-snug">
            Say something like "Tell me about my wedding day" or "Who is Susan?"
          </p>
        </div>
      </div>
    </div>
  );
};

export default HomeScreen;
