
import React from 'react';
import { FamilyMember, AppRoute } from '../types';
import { MOCK_FAMILY } from '../constants';

interface FamilyScreenProps {
  onSelectMember: (m: FamilyMember) => void;
  onNavigate: (r: AppRoute) => void;
}

const FamilyScreen: React.FC<FamilyScreenProps> = ({ onSelectMember }) => {
  return (
    <div className="relative flex h-full w-full flex-col bg-background-dark font-display overflow-hidden">
      <header className="flex items-center p-6 pb-4 justify-between pt-10">
        <h1 className="text-on-surface text-3xl font-extrabold tracking-tight">Family</h1>
        <button className="flex cursor-pointer items-center justify-center rounded-full size-12 bg-surface-variant text-on-surface">
          <span className="material-symbols-outlined">add</span>
        </button>
      </header>

      <main className="flex-1 px-4 overflow-y-auto pb-8">
        <div className="grid grid-cols-1 gap-4 max-w-md mx-auto">
          {MOCK_FAMILY.map((member) => (
            <button 
              key={member.id} 
              onClick={() => onSelectMember(member)}
              className="flex items-center gap-4 p-3 pr-5 rounded-[24px] bg-surface-variant/40 border border-white/5 active:bg-surface-variant/70 transition-colors text-left"
            >
              <div 
                className="size-20 shrink-0 rounded-[20px] bg-center bg-no-repeat bg-cover shadow-lg" 
                style={{ backgroundImage: `url("${member.imageUrl}")` }}
              ></div>
              <div className="flex-1 py-1">
                <h2 className="text-on-surface text-lg font-bold">{member.name}</h2>
                <p className="text-on-surface/60 text-sm font-medium">{member.relationship}</p>
                {member.isVoiceCloned && (
                  <div className="flex items-center gap-1 mt-1.5 text-primary text-[10px] font-bold uppercase tracking-wider">
                    <span className="material-symbols-outlined !text-[12px] material-fill">verified</span>
                    <span>Voice Cloned</span>
                  </div>
                )}
              </div>
              <span className="material-symbols-outlined text-primary">arrow_forward_ios</span>
            </button>
          ))}
        </div>
        
        <div className="mt-8 px-2">
          <h3 className="text-on-surface/40 text-xs font-bold uppercase tracking-widest mb-4">Discovery</h3>
          <div className="bg-primary-blue/10 rounded-2xl p-5 border border-primary-blue/20">
             <div className="flex items-start gap-4">
                <span className="material-symbols-outlined text-primary-blue text-3xl">auto_fix_high</span>
                <div>
                  <h4 className="text-primary-blue font-bold">New Photos Found</h4>
                  <p className="text-primary-blue/70 text-sm mt-1">We've identified 12 new photos of Susan and Emily. Would you like to add them to your memories?</p>
                </div>
             </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default FamilyScreen;
