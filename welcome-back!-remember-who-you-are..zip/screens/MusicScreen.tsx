
import React from 'react';

interface MusicScreenProps {
  onBack: () => void;
}

const MusicScreen: React.FC<MusicScreenProps> = ({ onBack }) => {
  return (
    <div className="bg-background-dark text-on-surface h-full flex flex-col overflow-hidden pt-10 font-display">
      <header className="px-6 py-4 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight text-on-surface">Therapeutic Music</h1>
        <button className="flex h-12 w-12 items-center justify-center rounded-2xl bg-surface-variant text-on-surface">
          <span className="material-symbols-outlined">playlist_add</span>
        </button>
      </header>

      <main className="flex-1 overflow-y-auto px-4 pb-8">
        <div className="mb-8">
          <div className="bg-primary/10 rounded-[28px] p-6 border border-primary/20 flex flex-col items-center text-center gap-4">
            <div className="size-16 rounded-full bg-primary flex items-center justify-center text-on-primary">
              <span className="material-symbols-outlined !text-3xl material-fill">auto_fix_high</span>
            </div>
            <div>
              <h2 className="text-xl font-bold">AI Radio</h2>
              <p className="text-on-surface/60 text-sm mt-1">Generating a playlist of your favorite hits from the 1960s to help trigger positive memories.</p>
            </div>
            <button className="w-full py-4 bg-primary text-on-primary font-bold rounded-2xl shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2">
              <span className="material-symbols-outlined material-fill">play_circle</span>
              <span>Start Therapy Session</span>
            </button>
          </div>
        </div>

        <h3 className="text-on-surface/40 text-xs font-bold uppercase tracking-widest mb-4 px-2">Connected Services</h3>
        <div className="space-y-3">
          <ServiceCard 
            icon="podcasts" 
            title="Spotify" 
            subtitle="Connected as Harri J." 
            color="#1DB954" 
            isConnected 
          />
          <ServiceCard 
            icon="music_note" 
            title="Apple Music" 
            subtitle="Link your account" 
            color="#FC3C44" 
          />
          <ServiceCard 
            icon="youtube_activity" 
            title="YouTube Music" 
            subtitle="Link your account" 
            color="#FF0000" 
          />
        </div>

        <h3 className="text-on-surface/40 text-xs font-bold uppercase tracking-widest mt-10 mb-4 px-2">Memory Mixes</h3>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-surface-variant/40 rounded-2xl p-4 border border-white/5 flex flex-col gap-3">
            <div className="w-full aspect-square bg-blue-500/20 rounded-xl flex items-center justify-center">
              <span className="material-symbols-outlined !text-4xl text-blue-400">water_drop</span>
            </div>
            <div>
              <p className="font-bold text-sm">Summer Lake 1965</p>
              <p className="text-xs text-on-surface/50">12 tracks</p>
            </div>
          </div>
          <div className="bg-surface-variant/40 rounded-2xl p-4 border border-white/5 flex flex-col gap-3">
            <div className="w-full aspect-square bg-amber-500/20 rounded-xl flex items-center justify-center">
              <span className="material-symbols-outlined !text-4xl text-amber-400">cake</span>
            </div>
            <div>
              <p className="font-bold text-sm">Birthday Jams</p>
              <p className="text-xs text-on-surface/50">8 tracks</p>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

const ServiceCard: React.FC<{ icon: string; title: string; subtitle: string; color: string; isConnected?: boolean }> = ({ icon, title, subtitle, color, isConnected }) => (
  <div className="flex items-center gap-4 p-4 rounded-3xl bg-surface-variant/40 border border-white/5">
    <div className="size-12 rounded-2xl flex items-center justify-center text-white" style={{ backgroundColor: color }}>
      <span className="material-symbols-outlined material-fill">{icon}</span>
    </div>
    <div className="flex-1">
      <h4 className="font-bold text-base">{title}</h4>
      <p className={`text-xs ${isConnected ? 'text-primary' : 'text-on-surface/50'} font-medium`}>{subtitle}</p>
    </div>
    <button className={`px-4 py-2 rounded-xl text-xs font-bold ${isConnected ? 'bg-surface-variant text-on-surface/40' : 'bg-on-surface text-surface'}`}>
      {isConnected ? 'Settings' : 'Link'}
    </button>
  </div>
);

export default MusicScreen;
