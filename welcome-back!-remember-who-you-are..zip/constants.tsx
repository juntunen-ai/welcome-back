
import { Memory, FamilyMember } from './types';

export const MOCK_FAMILY: FamilyMember[] = [
  {
    id: '1',
    name: 'Jane',
    relationship: 'Daughter',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBxl_an1o25lckTNUAoKZlG4GshDvynmYAKcixXpKubhR5VBxgSG3YSkAlCpCtophhgxYhx57L6MyEgd09lRxgT64-FcqQtZWuYTkhSjUSEQrOzB9Hn1FzaT3obFnRuQRoeftg8eSAnoWAi-MLec8xuGo8zheZfAh1M_p6Y87YBjE8eWBgw4GAnzeJMa4vFghAV1yQ-cE-i0E6hQY9yW9097Q-gbGG_x3YPgtNWURcxe72dLoFihnzxNF4GH5p0ffRsFZ01-0TReSw',
    isVoiceCloned: true
  },
  {
    id: '2',
    name: 'Michael',
    relationship: 'Son',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAU2-hWgjGO2F7a9ZpKZoA-WrQR-_sx4iqR9C9q2pFo7etu6QptvMyUAoM2gvDKFrbPD6C3IxtXgdlkcPs9Y5JcTxaaD1I5jtJOsp2gGOuYf0diu0yNZVK9ObBZbSTWN-Uiotu0-Vq5lGE8d6ZOHA-kXQBNaNdLBmnRlz84Xp3f9EYceuIPwraSZXULRbeR1lhYR2kDm-0zfhAjiJbsHbGItVxoBZcE9LobTlzTbH1C1fxJcs5UclIYk30RJZiMImdCHpNTFYR24jw',
    isVoiceCloned: false
  },
  {
    id: '3',
    name: 'Susan',
    relationship: 'Wife',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC0igb-o-fhBiwx6LRvmhv3kNPQM1OC58mCr_SOoEUc1_Rn0u-5rQqnDyJMDoJQSUiNZZ9i9i0AXjZNEWlaa7KOoCIw2PKsM9PGZD4mooQa6pFS-A5_rBGO5dwqTrLUvUCHRtzvIF7ZMB3TSd-vKBmxHB0hRuNR9PvfFcWBfbPAGe8lRNthDIz86oJmvbAwn1bx6kkW7W2949jjJD-CWnqEZ_sGdd_QUe60Cpaq0VLV0XOPuqdoiw8wSSzarvXYSKeiLbRNfCneq60',
    isVoiceCloned: true
  },
  {
    id: '4',
    name: 'Emily',
    relationship: 'Grandchild',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCC38_21cZ3TSwv__YgAQ6ld6RkL20-aRdRFTpMyBBQhLb5DjDPOwrbYGGVBuiTBG9HtlXorpRhG4UOPRR7ehc4tya2cUaM0867A3Jd-EyyWh7QUOOxC5xXiRU1CJaUKwAxBUteJAnM5-JvPw7rnLaiQUvEkLWOysRRGc8rw_YgnMmvFJY-oqo06GSU44LuCG5e88LOI3zhyeQnfx-vKjMVoOYo5WQ9xoXmgbOS_P3Qg7tFRrM_jYD_3wndLHpYiTRKZqpTM2jEaM0',
    isVoiceCloned: true
  }
];

export const MOCK_MEMORIES: Memory[] = [
  {
    id: '1',
    title: 'Family Reunion at Lake House',
    date: 'Summer 1965',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAA60gYZbqy_azxRw7Tn-zvCoudt48GKWlUBwIbsDY4A98BKMP1u7F7jrgEiXP00i3pqENutFxhJc6ejw_rrrawqaystphMGxV2A-_eZhB5Nn8pyBjU9rM7n8WAHHuZuQRjoXUxuALafQ3NGcVXVvZ7cOp4vxu7Es-E7-ob5xPMgytLznK131cpNu6BCYILY25tVFxWg0Nf9y8sCQ2BYkdpoTitmeAPicstbe0V1YW17ciVyNUR8op0u9cwnTWn0uM0rQZUDKaP884',
    category: 'Family',
    description: 'A beautiful sunny day at the lake with everyone gathered.'
  },
  {
    id: '2',
    title: 'Granddaughter Sarah',
    date: 'March 2021',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAw2gXI-S4lmZszZTRO8rHlD0kduT6F6gQxXb7CFdQPxCpUdTqDWXYSDwR1XwgTKHrq__5mnMrK7n2JGBGIZYLIv1RhBQrxCLNWhW7Y7kWdswDSKFkjVE1VxoaOkUbNHN1vu50uPqvn69d5zRhrZKxbC4zxO5f985LkdI4lXCgeBuHQyB4XyACOUTczMx9Tw6DoUkSpqf8leY8-mCMPB6nTJoMAYB18ObPDTggF6m1yYvMhYCOUR_-QenWYtDUeQqc7lKNUoUOJRk8',
    category: 'Family',
    description: 'Sarah visiting for the holidays.'
  },
  {
    id: '3',
    title: 'June 1960 Birthday',
    date: 'June 1960',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBck1cCu_tsRy9-LCojag9MeeYNRkRl0bnlRlayfAAdYsD4_XIP8qJK53QfoUNNBrqjqkWmxCl8oALbs16M49D18U-iLpXHfaDMy8dd-IV9kpnUSMin53vAbz-GUEfztIi7-uwol12dWh0NBa7oMoY6Lc-r7BT0E5d00xm6cIyIJYOZQcqf22qb1VmLmChgUBl9Jq2BuWvgKC-i2DZSLl9nV1I5ninKIowUAoHXa31OhckPuYg3GsORADTxTMOk431t8__5LwpHugo',
    category: 'Events',
    description: 'A celebration with a big blue cake.'
  },
  {
    id: '4',
    title: 'The Lake',
    date: 'August 1972',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCVF6znXcTHr7o4zaqUXjtY10e6i4wfNXopH7ZHOl5F31O_nCsCN2JtOvrbAK2nV6J94aMJWQkJTuqvgWmha-uYSmyQhQlQrTqRfI4k4ov5p3S-mQxHAkHXB38RrlmDa2mimdUXnuU6mlMD4FYWVY175YTJEMbpz2uVQG-DG3YutfG7Bx8EMghC8IC4YrSjrZ0HltbvcAutn9aOeSb2PZJYfw3JEYjw3sa_euBmfe6YXp0xa42vpEY8KWtocHtAy4c_ykUbHtbVfD0',
    category: 'Places',
    description: 'Quiet moments by the water.'
  }
];
