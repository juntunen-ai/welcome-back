
import React, { useState } from 'react';
import { AppRoute, Memory, FamilyMember } from './types';
import { MOCK_FAMILY, MOCK_MEMORIES } from './constants';
import HomeScreen from './screens/HomeScreen';
import MemoriesScreen from './screens/MemoriesScreen';
import FamilyScreen from './screens/FamilyScreen';
import ListeningScreen from './screens/ListeningScreen';
import PlaybackScreen from './screens/PlaybackScreen';
import SettingsScreen from './screens/SettingsScreen';
import MusicScreen from './screens/MusicScreen';

// Mock Android Status Bar Component
const AndroidStatusBar: React.FC = () => {
  const [time, setTime] = useState(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
  
  React.useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
    }, 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed top-0 left-0 right-0 h-8 flex items-center justify-between px-6 z-[60] text-on-surface font-medium text-xs pointer-events-none">
      <span>{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="material-symbols-outlined !text-[14px]">signal_cellular_4_bar</span>
        <span className="material-symbols-outlined !text-[14px]">wifi</span>
        <span className="material-symbols-outlined !text-[14px]">battery_5_bar</span>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [currentRoute, setCurrentRoute] = useState<AppRoute>(AppRoute.HOME);
  const [selectedFamilyMember, setSelectedFamilyMember] = useState<FamilyMember | null>(null);

  const navigateTo = (route: AppRoute) => {
    setCurrentRoute(route);
  };

  const handleStartListening = () => {
    navigateTo(AppRoute.LISTENING);
  };

  const handleDoneSpeaking = () => {
    const randomMember = MOCK_FAMILY[Math.floor(Math.random() * MOCK_FAMILY.length)];
    setSelectedFamilyMember(randomMember);
    navigateTo(AppRoute.PLAYBACK);
  };

  const renderScreen = () => {
    switch (currentRoute) {
      case AppRoute.HOME:
        return <HomeScreen onStartListening={handleStartListening} />;
      case AppRoute.MEMORIES:
        return <MemoriesScreen onSelectMemory={(m) => { navigateTo(AppRoute.PLAYBACK); }} onNavigate={navigateTo} />;
      case AppRoute.FAMILY:
        return <FamilyScreen onSelectMember={(m) => { setSelectedFamilyMember(m); navigateTo(AppRoute.PLAYBACK); }} onNavigate={navigateTo} />;
      case AppRoute.MUSIC:
        return <MusicScreen onBack={() => navigateTo(AppRoute.HOME)} />;
      case AppRoute.LISTENING:
        return <ListeningScreen onDone={handleDoneSpeaking} onClose={() => navigateTo(AppRoute.HOME)} />;
      case AppRoute.PLAYBACK:
        return <PlaybackScreen member={selectedFamilyMember} onBack={() => navigateTo(AppRoute.HOME)} />;
      case AppRoute.SETTINGS:
        return <SettingsScreen onBack={() => navigateTo(AppRoute.HOME)} />;
      default:
        return <HomeScreen onStartListening={handleStartListening} />;
    }
  };

  return (
    <div className="h-screen w-full relative overflow-hidden bg-background-dark android-nav-bar flex flex-col">
      <AndroidStatusBar />
      
      <div className="flex-1 overflow-hidden">
        {renderScreen()}
      </div>
      
      {/* MD3 Bottom Navigation Bar */}
      {[AppRoute.HOME, AppRoute.MEMORIES, AppRoute.FAMILY, AppRoute.MUSIC, AppRoute.SETTINGS].includes(currentRoute) && (
        <nav className="flex-shrink-0 flex gap-0.5 bg-surface/95 backdrop-blur-xl px-1 pb-8 pt-3 z-50 border-t border-white/5">
          <NavItem 
            isActive={currentRoute === AppRoute.HOME} 
            icon="home" 
            label="Home" 
            onClick={() => navigateTo(AppRoute.HOME)} 
          />
          <NavItem 
            isActive={currentRoute === AppRoute.MEMORIES} 
            icon="photo_library" 
            label="Memories" 
            onClick={() => navigateTo(AppRoute.MEMORIES)} 
          />
          <NavItem 
            isActive={currentRoute === AppRoute.FAMILY} 
            icon="groups" 
            label="Family" 
            onClick={() => navigateTo(AppRoute.FAMILY)} 
          />
          <NavItem 
            isActive={currentRoute === AppRoute.MUSIC} 
            icon="library_music" 
            label="Music" 
            onClick={() => navigateTo(AppRoute.MUSIC)} 
          />
          <NavItem 
            isActive={currentRoute === AppRoute.SETTINGS} 
            icon="settings" 
            label="Settings" 
            onClick={() => navigateTo(AppRoute.SETTINGS)} 
          />
        </nav>
      )}
    </div>
  );
};

const NavItem: React.FC<{ isActive: boolean; icon: string; label: string; onClick: () => void }> = ({ isActive, icon, label, onClick }) => (
  <button 
    onClick={onClick}
    className={`flex flex-1 flex-col items-center justify-center gap-1 transition-all relative ${isActive ? 'active' : 'text-on-surface/60'}`}
  >
    <div className="relative h-8 w-14 flex items-center justify-center">
      <div className="nav-indicator"></div>
      <span className={`material-symbols-outlined !text-[24px] ${isActive ? 'material-fill text-on-surface' : ''}`}>{icon}</span>
    </div>
    <span className="text-[10px] font-bold tracking-tight whitespace-nowrap">{label}</span>
  </button>
);

export default App;
