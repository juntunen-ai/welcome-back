
export interface Memory {
  id: string;
  title: string;
  date: string;
  imageUrl: string;
  category: string;
  description: string;
}

export interface FamilyMember {
  id: string;
  name: string;
  relationship: string;
  imageUrl: string;
  isVoiceCloned: boolean;
}

export enum AppRoute {
  HOME = 'home',
  MEMORIES = 'memories',
  FAMILY = 'family',
  MUSIC = 'music',
  LISTENING = 'listening',
  SETTINGS = 'settings',
  PLAYBACK = 'playback'
}
