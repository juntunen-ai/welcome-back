
import { GoogleGenAI } from "@google/genai";

const API_KEY = process.env.API_KEY || "";

export const generateMemoryStory = async (userName: string, familyMemberName: string, relationship: string) => {
  if (!API_KEY) return "I'm here to help you remember, Harri. You are loved by your family.";

  try {
    const ai = new GoogleGenAI({ apiKey: API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are ${familyMemberName}, the ${relationship} of ${userName}. 
      ${userName} is struggling with memory. 
      Speak directly to him as ${familyMemberName}. 
      Remind him of who he is and how much he is loved in a short, warm, and comforting paragraph (3-4 sentences).`,
      config: {
        temperature: 0.7,
        topP: 0.8,
      }
    });

    return response.text || "I'm here with you, Harri.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return `Hi Harri, it's ${familyMemberName}. We are all thinking of you today.`;
  }
};
